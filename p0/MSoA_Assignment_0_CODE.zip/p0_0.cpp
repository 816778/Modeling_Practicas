#include <iostream>
#include <math.h>

int main() {
	float x, y;
    std::cout << "Introduce x and y coordinates (sep. by space): ";
    std::cin >> x >> y;
    std::cout << "You have introduced " << x << " and " << y << std::endl;
    return 0;
}