/*
	This file is part of Nori, a simple educational ray tracer
	Copyright (c) 2020 by Adrian Jarabo
	Nori is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License Version 3
	as published by the Free Software Foundation.
	Nori is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	You should have received a copy of the GNU General Public License
	along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include <nori/emitter.h>
#include <nori/bitmap.h>
#include <nori/warp.h>
#include <filesystem/resolver.h>
#include <fstream>


NORI_NAMESPACE_BEGIN

class EnvironmentEmitter : public Emitter {
public:
	EnvironmentEmitter(const PropertyList& props) {
		m_type = EmitterType::EMITTER_ENVIRONMENT;
		m_environment = 0;

		std::string m_environment_name = props.getString("filename", "null");

		filesystem::path filename =
			getFileResolver()->resolve(m_environment_name);

		std::ifstream is(filename.str());
		if (!is.fail())
		{
			cout << "Loading Environment Map: " << filename.str() << endl;

			m_environment = new Bitmap(filename.str());
			cout << "Loaded " << m_environment_name << " - SIZE [" << m_environment->rows() << ", " << m_environment->cols() << "]" << endl;
		}
		m_radiance = props.getColor("radiance", Color3f(1.));
		m_radiance_c = props.getColor("radiance", Color3f(1.));
	}
	~EnvironmentEmitter()
	{
		if (m_environment)
			delete m_environment;
	}

	virtual std::string toString() const {
		return tfm::format(
			"AreaLight[\n"
			"  radiance = %s,\n"
			"  environment = %s,\n"
			"]",
			m_radiance.toString(),
			m_environment_name);
	}

	// We don't assume anything about the visibility of points specified in 'ref' and 'p' in the EmitterQueryRecord.
	virtual Color3f eval(const EmitterQueryRecord& lRec) const {

		// This function call can be done by bsdf sampling routines.
		// Hence the ray was already traced for us - i.e a visibility test was already performed.
		// Hence just check if the associated normal in emitter query record and incoming direction are not backfacing
		if (!m_environment)
			return m_radiance;

		float phi = atan2(lRec.wi[2], lRec.wi[0]);
		float theta = acos(lRec.wi[1]);
		if (phi < 0) phi += 2 * M_PI;

		float x = phi / (2 * M_PI);
		float y = (theta) / M_PI;


		return m_environment->eval(Point2f(x, y))* m_radiance;
	}

	virtual Color3f sample(EmitterQueryRecord& lRec, const Point2f& sample, float optional_u) const {
		// θ: ángulo polar [0, pi], φ: ángulo azimutal [0, 2*pi]
		// convertir a coordenadas esféricas
		float theta = std::acos(1.0f - 2.0f * sample.x()); 
    	float phi = 2.0f * M_PI * sample.y();

		// convertir (θ, φ) en una dirección en el entorno (wi)
		lRec.wi = Vector3f(
        std::sin(theta) * std::cos(phi),  // x
        std::cos(theta),                  // y
        std::sin(theta) * std::sin(phi)   // z
    	);
		//distancia a la fuente de luz es "infinita" porque es un mapa de entorno
		lRec.dist = std::numeric_limits<float>::infinity();

		// Convertir las coordenadas esféricas en coordenadas de textura (u, v)
		float u = phi / (2.0f * M_PI);   // Normalizar phi a [0, 1]
    	float v = theta / M_PI;

		if (m_environment) {
			return m_environment->eval(Point2f(u, v)) * m_radiance;
		}

		 return m_radiance;
	}

	// Returns probability with respect to solid angle given by all the information inside the emitterqueryrecord.
	// Assumes all information about the intersection point is already provided inside.
	// WARNING: Use with care. Malformed EmitterQueryRecords can result in undefined behavior. Plus no visibility is considered.
	virtual float pdf(const EmitterQueryRecord& lRec) const {
		return 1.0f / (4.0f * M_PI);
	}


	// Get the parent mesh
	void setParent(NoriObject* parent)
	{
	}


protected:
	Color3f m_radiance;
	Bitmap *m_environment;
	std::string m_environment_name;
};

NORI_REGISTER_CLASS(EnvironmentEmitter, "environment")
NORI_NAMESPACE_END
