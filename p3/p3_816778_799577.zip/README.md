# Monte Carlo-Based Materials

**Authors:**

- Eryka Liced Rimacuna Castillo     816778
- Javier Franco Ramírez             799577


**Extras**

- Multiple Importance Sampling


**References**

- All figures are: https://drive.google.com/file/d/1U6K-N4j-_WV91dSnJpTGRlgWZONKNCAH/view?usp=sharing

- https://pbr-book.org/4ed/Reflection_Models/Roughness_Using_Microfacet_Theory

- 


