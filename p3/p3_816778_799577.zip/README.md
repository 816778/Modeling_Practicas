# Monte Carlo-Based Materials

**Authors:**

- Eryka Liced Rimacuna Castillo     816778
- Javier Franco Ramírez             799577


**Extras**

- Multiple Importance Sampling


**References**

- https://pbr-book.org/4ed/Reflection_Models/Roughness_Using_Microfacet_Theory

- 


